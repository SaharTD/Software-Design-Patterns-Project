/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bookbookingsystem;

import bookbookingsystem.IBook.BookProxy;


/**
 *
 * @author USER
 */
public class BookBookingSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
     IBook bookProxy = new BookProxy("The Great Gatsby", "F. Scott Fitzgerald", 180);
        IBook book3 = new BookProxy("1984", "George Orwell", 328);
 
        // Access book information through the proxy
        System.out.println("Book Title: " + bookProxy.getTitle());
        System.out.println("Book Author: " + bookProxy.getAuthor());
        System.out.println("Book Pages: " + bookProxy.getPages());
}
}