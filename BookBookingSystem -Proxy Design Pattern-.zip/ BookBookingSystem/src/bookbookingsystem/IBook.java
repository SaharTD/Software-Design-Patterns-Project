/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package bookbookingsystem;

/**
 *
 * @author USER
 */
public interface IBook {
       String getTitle();
    String getAuthor();
    int getPages();


/**
 * RealBook represents the actual Book object.
 */
public class RealBook implements IBook {
    private final String title;
    private final String author;
    private final int pages;

    public RealBook(String title, String author, int pages) {
        this.title = title;
        this.author = author;
        this.pages = pages;
    }

    @Override
    public String getTitle() {
        return title;
    }

    @Override
    public String getAuthor() {
        return author;
    }

    @Override
    public int getPages() {
        return pages;
    }
}

/**
 * BookProxy serves as a proxy for the Book object.
 * It provides additional functionality or controls access to the RealBook object.
 */
public class BookProxy implements IBook {
    private RealBook realBook;

    public BookProxy(String title, String author, int pages) {
        this.realBook = new RealBook(title, author, pages);
    }

    /**
     * Lazily loads the RealBook object and delegates the getTitle() method call to it.
            * @return 
     */
    @Override
    public String getTitle() {
        loadRealBook();
        return realBook.getTitle();
    }

    /**
     * Lazily loads the RealBook object and delegates the getAuthor() method call to it.
            * @return 
     */
    @Override
    public String getAuthor() {
        loadRealBook();
        return realBook.getAuthor();
    }

    /**
     * Lazily loads the RealBook object and delegates the getPages() method call to it.
     */
    @Override
    public int getPages() {
        loadRealBook();
        return realBook.getPages();
    }

    /**
     * Loads the RealBook object if it hasn't been loaded already.
     */
    private void loadRealBook() {
        if (realBook == null) {
            // Simulate loading book from a database or external source
            realBook = new RealBook("Default Title", "Default Author", 0);
        }
    }
       }
}