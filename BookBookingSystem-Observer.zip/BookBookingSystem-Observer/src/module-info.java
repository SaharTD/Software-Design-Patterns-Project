/**
 * 
 */
/**
 * @author LENOVO
 *
 */
module pattern {
}