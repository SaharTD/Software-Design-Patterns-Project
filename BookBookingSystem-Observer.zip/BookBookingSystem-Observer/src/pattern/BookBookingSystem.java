package pattern;

import java.util.List;
import java.util.ArrayList;
import java.util.List;

public class BookBookingSystem {
    public static void main(String[] args) {
        // Create some books
        Book book1 = new Book("The Great Gatsby", "F. Scott Fitzgerald", 180);
        Book book2 = new Book("To Kill a Mockingbird", "Harper Lee", 281);
        Book book3 = new Book("1984", "George Orwell", 328);

        // Create some customers
        Customer customer1 = new Customer("John Doe", "john@example.com");
        Customer customer2 = new Customer("Jane Smith", "jane@example.com");

        // Create a library and add books to it
        Library library = new Library();
        library.addBook(book1);
        library.addBook(book2);
        library.addBook(book3);

        // Add customers as observers
        library.addObserver(customer1);
        library.addObserver(customer2);

        // Display all books in the library
        List<Book> allBooks = library.getAllBooks();
        System.out.println("Books available in the library:");
        for (Book book : allBooks) {
            System.out.println(book.getTitle() + " by " + book.getAuthor());
        }
    }
}