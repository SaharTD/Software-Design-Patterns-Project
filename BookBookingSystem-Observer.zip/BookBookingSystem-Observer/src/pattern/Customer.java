package pattern;

public class Customer implements Observer {
    private String name;
    private String email;

    public Customer(String name, String email) {
        this.name = name;
        this.email = email;
    }

    // Getters and setters

    @Override
    public void update(Book book, String action) {
        System.out.println("Notification for " + name + ": Book " + book.getTitle() + " " + action);
    }
}
