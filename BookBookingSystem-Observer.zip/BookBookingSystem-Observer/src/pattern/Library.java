package pattern;
import java.util.List;
import java.util.ArrayList;


import java.util.ArrayList;
import java.util.List;

public class Library {
    private final List<Book> books;
    private final List<Observer> observers;

    public Library() {
        this.books = new ArrayList<>();
        this.observers = new ArrayList<>();
    }

    // Add observer
    public void addObserver(Observer observer) {
        observers.add(observer);
    }

    // Remove observer
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    // Notify observers
    private void notifyObservers(Book book, String action) {
        for (Observer observer : observers) {
            observer.update(book, action);
        }
    }

    // Add a book to the library
    public void addBook(Book book) {
        books.add(book);
        notifyObservers(book, "added");
    }

    // Remove a book from the library
    public void removeBook(Book book) {
        books.remove(book);
        notifyObservers(book, "removed");
    }

    // Get all books in the library
    public List<Book> getAllBooks() {
        return new ArrayList<>(books);
    }
}
