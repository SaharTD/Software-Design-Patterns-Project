package pattern;

import java.util.Observable;

interface Observer {
    void update(Book book, String action);
}