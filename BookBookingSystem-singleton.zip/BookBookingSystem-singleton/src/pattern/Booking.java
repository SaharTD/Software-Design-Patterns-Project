package pattern;

public class Booking {
	private Customer customer;
    private Book book;

    public Booking(Customer customer, Book book) {
        this.customer = customer;
        this.book = book;
    }

    // Getters
    public Customer getCustomer() {
        return customer;
    }

    public Book getBook() {
        return book;
    }
}
