package pattern;
import java.util.List;
import java.util.ArrayList;


public class Library {
	 private List<Book> books;

	    private static Library instance;

	    private Library() {
	        this.books = new ArrayList<>();
	    }

	    public static Library getInstance() {
	        if (instance == null) {
	            instance = new Library();
	        }
	        return instance;
	    }

	    // Add a book to the library
	    public void addBook(Book book) {
	        books.add(book);
	    }

	    // Remove a book from the library
	    public void removeBook(Book book) {
	        books.remove(book);
	    }

	    // Get all books in the library
	    public List<Book> getAllBooks() {
	        return new ArrayList<>(books);
	    }
}
