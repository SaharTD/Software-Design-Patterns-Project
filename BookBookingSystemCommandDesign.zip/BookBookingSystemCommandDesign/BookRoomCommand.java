/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookbookingsystem;

public class BookRoomCommand implements Command {
    
   private StudyRoom studyRoom;
    private int hours;

    public BookRoomCommand(StudyRoom studyRoom, int hours) {
        this.studyRoom = studyRoom;
        this.hours = hours;
    }

    @Override
    public void execute() {
        studyRoom.bookRoom(hours);
    }
}



