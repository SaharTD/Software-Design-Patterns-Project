/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookbookingsystem;

/**
 *
 * @author ruway
 */
public class SellStock implements InfoOrder {
    private Stock stock;

    public SellStock(Stock stock) {
        this.stock = stock;
    }

    
    public void execute() {
        stock.sell();
    }
}
