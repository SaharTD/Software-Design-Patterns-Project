/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bookbookingsystem;

/**
 *
 * @author suhai
 */

import java.util.List;

// ExternalBookAdapter adapts the interface of ExternalBookSource to work with Library
class ExternalBookAdapter {
    private final ExternalBookSource externalBookSource;

    public ExternalBookAdapter(ExternalBookSource externalBookSource) {
        this.externalBookSource = externalBookSource;
    }

    // Method to add books from the external source to the Library
    public void addExternalBooksToLibrary(Library library) {
        List<Book> externalBooks = externalBookSource.getAllExternalBooks();
        for (Book book : externalBooks) {
            library.addBook(book);
        }
    }
}
