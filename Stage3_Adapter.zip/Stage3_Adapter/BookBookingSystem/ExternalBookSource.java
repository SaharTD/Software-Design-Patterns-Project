/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bookbookingsystem;

/**
 *
 * @author suhai
 */

import java.util.ArrayList;
import java.util.List;
// ExternalBookSource represents an external source of books with a different interface
class ExternalBookSource {
    private final List<Book> externalBooks;

    public ExternalBookSource() {
        this.externalBooks = new ArrayList<>();
        // Initialize with some external books
        externalBooks.add(new Book("The Catcher in the Rye", "J.D. Salinger", 224));
        externalBooks.add(new Book("Pride and Prejudice", "Jane Austen", 279));
    }

    // Method to retrieve all books from the external source
    public List<Book> getAllExternalBooks() {
        return new ArrayList<>(externalBooks);
    }
}
